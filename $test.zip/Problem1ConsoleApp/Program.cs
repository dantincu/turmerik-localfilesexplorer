﻿Console.WriteLine("Enter the value for exp:");
string exp = Console.ReadLine()!;
bool isBalanced = IsBalanced(exp);

string answer = isBalanced switch
{
    true => "Balanced",
    false => "Not Balanced"
};

Console.WriteLine(answer);

bool IsBalanced(string exp)
{
    var stack = new Stack<char>();
    char prevBracked = default;
    bool isBalanced = true;

    for (int i = 0; i < exp.Length; i++)
    {
        var currentBracket = exp[i];

        if (IsOpening(currentBracket))
        {
            if (prevBracked != default)
            {
                stack.Push(prevBracked);
            }
            
            prevBracked = currentBracket;
        }
        else if (IsClosing(currentBracket))
        {
            if (Matches(prevBracked, currentBracket))
            {
                if (!stack.TryPop(out prevBracked))
                {
                    prevBracked = default;
                }
            }
            else
            {
                isBalanced = false;
                break;
            }
        }
    }

    isBalanced = isBalanced && !stack.Any();
    return isBalanced;
}

bool IsOpening(char bracket) => "[({".Contains(bracket);
bool IsClosing(char bracket) => "])}".Contains(bracket);

bool Matches(char prevBracket, char currentBracket) => prevBracket switch
{
    '[' => currentBracket == ']',
    '(' => currentBracket == ')',
    '{' => currentBracket == '}',
    _ => false
};