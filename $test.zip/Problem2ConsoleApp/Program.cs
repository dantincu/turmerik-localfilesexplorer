﻿Console.WriteLine("Type the numbers separating them with commas:");
string inputStr = Console.ReadLine();

int[] inputArr = ParseInput(inputStr);
int nonDupplicated = GetNonDupplicated(inputArr);

Console.WriteLine(nonDupplicated);

int[] ParseInput(string inputStr) => inputStr.Split(
    ',').Select(int.Parse).ToArray();

int GetNonDupplicated(int[] inputArr)
{
    var numsList = inputArr.ToList();
    int currentNum = numsList.First();
    numsList.RemoveAt(0);

    while (true)
    {
        int matchingIdx = numsList.IndexOf(currentNum);

        if (matchingIdx >= 0)
        {
            numsList.RemoveAt(matchingIdx);
            currentNum = numsList.First();
            numsList.RemoveAt(0);
        }
        else
        {
            break;
        }
    }

    return currentNum;
}